import React from 'react';
import DetectarImagen from './components/DetectarImagen';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <DetectarImagen />
    </div>
  );
}

export default App;