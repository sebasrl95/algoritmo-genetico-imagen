import React, { useState } from 'react';

const DetectarImagen = () => {
    const [imagen, setImagen] = useState(null);
    const [parametros, setParametros] = useState(null);
    const [loading, setLoading] = useState(false);

    const handleImageChange = (e) => {
        setImagen(e.target.files[0]);
    };

    const optimizarImagen = async () => {
        setLoading(true);
        const formData = new FormData();
        formData.append('image', imagen);

        try {
            const response = await fetch('http://localhost:5000/optimize-image', {
                method: 'POST',
                body: formData,
            });

            const data = await response.json();
            setParametros(data.parametros);
        } catch (error) {
            console.error("Error al optimizar la imagen", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <input type="file" accept="image/*" onChange={handleImageChange} />
            <button onClick={optimizarImagen} disabled={!imagen || loading}>
                {loading ? 'Optimizando...' : 'Optimizar Imagen'}
            </button>

            {parametros && (
                <div>
                    <h3>Parámetros optimizados:</h3>
                    <p>Brillo: {parametros[0]}</p>
                    <p>Contraste: {parametros[1]}</p>
                    <p>Filtro aplicado: {parametros[2] === 1 ? 'Sí' : 'No'}</p>
                </div>
            )}
        </div>
    );
};

export default DetectarImagen;
