import random as rd
from PIL import Image, ImageFilter

# Función para aplicar un conjunto de filtros y evaluar el "fitness"
def evaluar_fitness_imagen(individuo, imagen_original):
    # Descomponemos los parámetros de la solución (individuo)
    brillo, contraste, filtro = individuo

    # Aplicamos los ajustes a la imagen
    imagen_modificada = imagen_original.convert('L')  # Pasamos a escala de grises
    imagen_modificada = imagen_modificada.point(lambda p: p * brillo)
    imagen_modificada = imagen_modificada.point(lambda p: p * contraste)

    # Aplicamos un filtro si el individuo lo sugiere
    if filtro == 1:
        imagen_modificada = imagen_modificada.filter(ImageFilter.FIND_EDGES)

    # Calculamos el fitness (por ejemplo, cantidad de bordes encontrados)
    fitness = sum(imagen_modificada.getdata()) / len(imagen_modificada.getdata())

    return fitness

# Algoritmo genético para optimización de detección de imagen
def algoritmo_genetico_imagen(imagen, numero_generaciones=100, tamano_poblacion=50, tasa_mutacion=0.01):
    # Inicializamos la población (conjunto de parámetros de brillo, contraste y filtro)
    poblacion = [[rd.uniform(0.5, 1.5), rd.uniform(0.5, 1.5), rd.randint(0, 1)] for _ in range(tamano_poblacion)]

    for generacion in range(numero_generaciones):
        # Evaluamos el fitness de cada individuo
        adaptaciones = [(individuo, evaluar_fitness_imagen(individuo, imagen)) for individuo in poblacion]

        # Ordenamos por adaptación (fitness)
        adaptaciones.sort(key=lambda x: x[1], reverse=True)

        # Seleccionamos los mejores individuos
        mejores_individuos = [ind for ind, fitness in adaptaciones[:tamano_poblacion // 2]]

        # Generamos nueva población a partir de cruces y mutaciones
        nueva_poblacion = []
        while len(nueva_poblacion) < tamano_poblacion:
            padre1 = rd.choice(mejores_individuos)
            padre2 = rd.choice(mejores_individuos)
            hijo = cruce(padre1, padre2)
            hijo = mutacion(hijo, tasa_mutacion)
            nueva_poblacion.append(hijo)

        # Actualizamos la población
        poblacion = nueva_poblacion

    # Retornamos el mejor conjunto de parámetros
    mejor_individuo = max(poblacion, key=lambda ind: evaluar_fitness_imagen(ind, imagen))
    return mejor_individuo

# Función de cruce entre dos individuos
def cruce(padre1, padre2):
    punto_cruce = rd.randint(0, len(padre1) - 1)
    return padre1[:punto_cruce] + padre2[punto_cruce:]

# Función de mutación
def mutacion(individuo, tasa_mutacion):
    if rd.random() < tasa_mutacion:
        indice_mutacion = rd.randint(0, len(individuo) - 1)
        if indice_mutacion < 2:
            individuo[indice_mutacion] = rd.uniform(0.5, 1.5)
        else:
            individuo[indice_mutacion] = rd.randint(0, 1)
    return individuo
