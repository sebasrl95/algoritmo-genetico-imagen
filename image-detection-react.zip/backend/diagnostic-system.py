# Importar librerias necesarias
from flask import Flask, request, jsonify
from flask_cors import CORS
from algoritmo_genetico_deteccion_imagen import algoritmo_genetico_imagen

app = Flask(__name__)

# Habilitar CORS en la aplicación
CORS(app)

# Ruta para evaluar los sintomas
# Endpoint para optimizar la detección en una imagen
@app.route('/optimize-image', methods=['POST'])
def optimize_image():
    try:
        # Recuperamos la imagen enviada en la solicitud
        file = request.files['image']
        imagen = Image.open(io.BytesIO(file.read()))

        # Ejecutamos el algoritmo genético para optimizar los parámetros de detección
        parametros_optimizados = algoritmo_genetico_imagen(imagen)

        # Retornamos los parámetros optimizados
        return jsonify({"parametros": parametros_optimizados}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)